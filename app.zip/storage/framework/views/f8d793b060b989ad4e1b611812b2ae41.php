<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Add User</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6"></div>
                    <!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <?php if($errors->any()): ?>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="text-danger"> <?php echo e($error); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                       <form action="<?php echo e(route('users.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-7">
                                <div class="mb-3">
                                    <label for="">Name</label>
                                    <input type="text" name="name" class="form-control" placeholder="Enter user name">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="mb-3">
                                    <label for="">Email</label>
                                    <input type="text" name="email" class="form-control" placeholder="Enter user Email">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div class="mb-3">
                                    <label for="">password</label>
                                    <input type="password" name="password" class="form-control" placeholder="Enter user password">
                                </div>
                            </div>
                            <div class="col-md-7">
                                <button class="btn btn-primary">Save</button>
                            </div>
                        </div>
                       </form>
                    </div>
                </div>
                <br>

                <div class="card">
                    <div class="card-header">
                       <div class="row">
                        <div class="col-md-6">
                            <h4>All User List</h4>

                        </div>
                        <div class="col-md-6">
                            <div class="float-right">
                                <form action="<?php echo e(route('users.index')); ?>" method="GET">

                                    <div class="d-flex">
                                        <input type="text" name="emailsearch" class="form-control" value="<?php echo e(request()->get('emailsearch')); ?>" placeholder="Search by email">
                                    <button class="btn btn-primary btn-sm">Search</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                       </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$i); ?> </td>
                                        <td><?php echo e($user->name); ?> </td>
                                        <td><?php echo e($user->email); ?> </td>
                                        <td><?php echo e($user->show_password); ?> </td>
                                        <td class="d-flex">
                                        <a href="<?php echo e(route('users.show',$user->id)); ?>" class="btn btn-success btn-sm" style="margin-right: 2px">View</a>
                                        
                                        <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button  class="btn btn-danger btn-sm">Delete</button>

                                        </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table><br>
                        <?php echo $users->links(); ?>

                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/raj/Documents/laravel-paid/laravel-register-crud/crud/resources/views/admin/user/index.blade.php ENDPATH**/ ?>