<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6"></div>
                    <!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <?php if($errors->any()): ?>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-danger"><?php echo e($error); ?> </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>


                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>



                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('post.userinfo')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Image</label>
                                        <input type="file" name="profile_img" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Name</label>
                                        <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                                            placeholder="Enter Your name" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Educational qualification</label>
                                        <input type="text" value="<?php echo e(old('educational_qualification')); ?>"
                                            name="educational_qualification" placeholder="Enter Educational qualification"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Date Of Birth</label>
                                        <input type="date" value="<?php echo e(old('date_of_birth')); ?>" name="date_of_birth"
                                            placeholder="Date Of Birth" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Divisions</label>
                                        <select name="division" id="division" class="form-control">
                                            <option value="">Select Division</option>
                                            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($division->id); ?>"><?php echo e($division->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">District</label>
                                        <select name="district" id="district" class="form-control">
                                            <option value="">Select District</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Upazila</label>
                                        <select name="upazila" id="upazila" class="form-control">
                                            <option value="">Select Upazila</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Batch</label>
                                        <select class="form-control" name="batch" id="">
                                            <option value="">Select Batch</option>
                                            <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Working From</label>
                                        <input type="text" value="<?php echo e(old('working_from')); ?>" name="working_from"
                                            placeholder="Working From" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Appointed</label>
                                        <input type="text" value="<?php echo e(old('appointed')); ?>" name="appointed"
                                            placeholder="Appointed" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">CurrentPosting</label>
                                        <input type="text" value="<?php echo e(old('currentPosting')); ?>" name="currentPosting"
                                            placeholder="CurrentPosting" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">PreviousPosting</label>
                                        <input type="text" value="<?php echo e(old('previousposting')); ?>"
                                            name="previousposting" placeholder="PreviousPosting" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">BloodGroup</label>
                                        <input type="text" value="<?php echo e(old('bloodgroup')); ?>" name="bloodgroup"
                                            placeholder="BloodGroup" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Mobile</label>
                                        <input type="number" value="<?php echo e(old('mobile')); ?>" name="mobile"
                                            placeholder="Enter your mobile number" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="">Email</label>
                                        <input type="email" value="<?php echo e(old('email')); ?>" name="email"
                                            placeholder="Enter your Email number" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <center>
                                <button type="submit" class="btn btn-primary">Save</button>

                            </center>
                        </form>
                    </div>
                </div>

                <br>
                <br>

                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Profile</th>
                                        <th>Educational Qualification</th>
                                        <th>Date of birth</th>
                                        <th>Division</th>
                                        <th>District</th>
                                        <th>Upazila</th>
                                        <th>Batch</th>
                                        <th>Working From</th>
                                        <th>Appointed</th>
                                        <th>CurrentPosting</th>
                                        <th>Previousposting</th>
                                        <th>Bloodgroup</th>
                                        <th>Mobile</th>
                                        <th>Email</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><img src="<?php echo e(asset($user->profile_img)); ?>" style="width: 80px; "
                                                    alt=""> </td>
                                            <td><?php echo e($user->educational_qualification); ?> </td>
                                            <td><?php echo e($user->date_of_birth); ?> </td>
                                            <td><?php echo e($user->divisiondata->name); ?> </td>
                                            <td><?php echo e($user->districtdata->name); ?> </td>
                                            <td><?php echo e($user->upaziladata->name); ?> </td>
                                            <td><?php echo e($user->batchdata->name); ?> </td>
                                            <td><?php echo e($user->working_from); ?> </td>
                                            <td><?php echo e($user->appointed); ?> </td>
                                            <td><?php echo e($user->currentPosting); ?> </td>
                                            <td><?php echo e($user->previousposting); ?> </td>
                                            <td><?php echo e($user->bloodgroup); ?> </td>
                                            <td><?php echo e($user->mobile); ?> </td>
                                            <td><?php echo e($user->email); ?> </td>
                                            <td>
                                                <a href="<?php echo e(route('userformDelete', $user->id)); ?>"
                                                    class="btn btn-danger btn-sm">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#division').on('change', function() {
                var division_id = $(this).val();

                if (division_id) {
                    $('#district').prop('disabled', false);
                    $('#district').html('<option value="">Loading...</option>');
                    $('#upazila').prop('disabled', true);

                    $.ajax({
                        url: '/user/get-districts',
                        type: 'GET',
                        data: {
                            division_id: division_id
                        },
                        success: function(data) {
                            $('#district').html('<option value="">Select District</option>');
                            $.each(data, function(key, value) {
                                $('#district').append('<option value="' + key + '">' +
                                    value + '</option>');
                            });
                        }
                    });
                } else {
                    $('#district').prop('disabled', true);
                    $('#district').html('<option value="">Select District</option>');
                    $('#upazila').prop('disabled', true);
                    $('#upazila').html('<option value="">Select Upazila</option>');
                }
            });

            $('#district').on('change', function() {
                var district_id = $(this).val();

                if (district_id) {
                    $('#upazila').prop('disabled', false);

                    $('#upazila').html('<option value="">Loading...</option>');

                    $.ajax({
                        url: '/user/get-upazilas',
                        type: 'GET',
                        data: {
                            district_id: district_id
                        },
                        success: function(data) {
                            $('#upazila').html('<option value="">Select Upazila</option>');
                            $.each(data, function(key, value) {
                                $('#upazila').append('<option value="' + key + '">' +
                                    value + '</option>');
                            });
                        }
                    });


                } else {
                    $('#upazila').prop('disabled', true);
                    $('#upazila').html('<option value="">Select Upazila</option>');
                }

            })

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/raj/Documents/laravel-paid/laravel-register-crud/crud/resources/views/users/dashboard.blade.php ENDPATH**/ ?>